import torch
import torch.nn as nn
from model_zoo import model_dict
import time
import json
from statistics import median
import os
import glob
import torch.nn.functional as F


from util import *
torch.manual_seed(1)


def run_experiment(config):
    try:
        task_id = int(os.getenv("SLURM_ARRAY_TASK_ID")) - 1
    except:
        print("not running sbatch array")
        task_id = 0
    try:
        eval_config_dict = make_grid(config)[task_id]
    except:
        print("not enough tasks available")
        return
    prep_directories()
    if eval_config_dict.get('model_name', 'resnet50') == "vgg_astra":
        files = ["results/vgg16-best-0.99625-lr;0.001-bs;256-weight_decay;0-train_dir;real_data-val_dir;val-finetuned;False.json"]

    else:
        files = glob.glob(f"results/{eval_config_dict.get('model_name', 'resnet50')}*")
    print(files)
    for file in files:
        with open(file, 'r') as f:
            config_dict = json.load(f)
        try:
            if eval_config_dict.get('model_name', 'resnet50') == "vgg_astra":
                    model = model_dict[eval_config_dict.get("model_name")](pretrained=False, n_classes=4)
                    model.load_state_dict(torch.load("models/vgg16-best-0.99442-lr;0.001-bs;64-weight_decay;0-finetuned;True.pt"))
            else:
                model_checkpoint = find_model_checkpoint(file, eval_config_dict)
                if model_checkpoint is not None:
                    print(model_checkpoint)
                    n_classes = 525 if config_dict.get("bird", False) else 4
                    model = model_dict[eval_config_dict.get("model_name")](pretrained=False, n_classes=n_classes)
                    # model = model_dict["shufflenet"](pretrained=False, n_classes=n_classes)
                    print("built model")
                else: continue
                model.load_state_dict(torch.load(model_checkpoint))
        except:
            print("error")
            continue
        if config_dict.get("bird", False):
            train_dataloader, val_dataloader = get_bird_dataloader(config_dict)
        else:
            train_dataloader, val_dataloader = get_dataloader(config_dict)
        
        val_loss, val_acc, hard_preds, labels, batch_time = validate(model, loss_fn = nn.CrossEntropyLoss(), val_loader=val_dataloader, config_dict=config_dict)
        config_dict["hard_preds"] = hard_preds
        config_dict["labels"] = labels
        config_dict["cpu_data_batch_time"] = batch_time
        with open(file, 'w') as fp:
            json.dump(config_dict, fp, indent=2)
        
    return 


def find_model_checkpoint(res_filename, config_dict):
    candidates = glob.glob(f"models/{config_dict.get('model_name', 'resnet50')}*")
    offset = 0
    if "mobilenet" in config_dict.get('model_name', 'resnet50'):
        offset += 2
    match_string = res_filename.split("\\")[1].split("-")[1 + offset]
    print(match_string)
    if ";" not in match_string:
        match_string = res_filename.split("\\")[1].split("-")[2 + offset]
    
    for candidate in candidates:
        if match_string in candidate:
            return candidate
    return None


def validate(model, loss_fn, val_loader, config_dict):
    # device = torch.device("cuda" if torch.cuda.is_available() 
    #                             else "cpu")
    device = torch.device("cpu")
    print(device)
    model.to(device)
    val_loss, val_acc, epoch_hard_preds, epoch_labels = [], [], [], []
    inf_batch_time = []
    model.eval()
    with torch.no_grad():
        for batch_index, (x, y) in enumerate(val_loader, 1):
            # print(x.size())
            # if not config_dict.get("bird", False):
            #     x = torch.repeat_interleave(x, 3, 1)
            t1 = time.time()
            inputs, labels = x.to(device), y.to(device)
            
            teacher_pred = model.forward(inputs)
            t2 = time.time()
            inf_batch_time.append(t2-t1)
            loss = loss_fn(teacher_pred, labels)
            val_loss.append(loss.item())
            hard_preds = F.softmax(teacher_pred, dim=1).argmax(dim=1)
            acc_batch_avg = (hard_preds.to(device) == labels).float().mean().item()
            val_acc.append(acc_batch_avg)
            epoch_hard_preds.extend(hard_preds.tolist())
            epoch_labels.extend(labels.tolist())
    return sum(val_loss)/len(val_loss), sum(val_acc)/len(val_acc), epoch_hard_preds, epoch_labels, sum(inf_batch_time)/len(inf_batch_time)


if __name__ == "__main__":
    with open('eval_config.json', 'r') as f:
        config = json.load(f)
    run_experiment(config)
    